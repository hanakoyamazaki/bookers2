# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'c635efa6a62a72ef08f2e644a535a4d4f926bc302f0df414e32c0c35680684b0f3911e2ddaaec3237e9529960767822fedd982b498e43e7ad4293459ad66b301'